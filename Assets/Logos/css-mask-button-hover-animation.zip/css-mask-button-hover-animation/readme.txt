This template / effect / code has been created by Yugam.
You can customize and check it out on its original site on the following link:
https://codepen.io/pizza3/pen/qmerBv

Thank you